﻿Public Class BrowserWindow
    Dim searchString As String

    Private Sub ButtonSearch_Click(sender As Object, e As EventArgs) Handles ButtonSearch.Click
        searchString = SearchBox.Text
        If searchString = "" Then
            MsgBox("Error in URL")
        Else
            Browser.Navigate(searchString)

        End If
    End Sub

End Class
